# Subiectul 2 (2.5 pts)
# Tematica: Javascript

# Avand urmatoarea functie `function render(input, values)` unde:
- `input` este un obiect
- `values` este un obiect
- Functia trebuie sa genereze un string cu tag-uri, similar cu un HTML
- Pentru valorile finale, dacă acestea conțin un marker de tipul `${key}`, marker-ul va fi înlocuit valoarea cheii din `values`

# Completați următoarele cerințe:
- funcția returnează un string vid dacă primul parametru este un obiect vid; (0.5 pts)
- funcția aruncă o excepție cu mesajul `InvalidType` dacă unul dintre parametrii primiți nu este un obiect; (0.5 pts)
- funcția returnează rezultatul corect pentru un caz simplu; (0.5 pts)
- funcția face substituție de token-uri; (0.5 pts)
- funcția returnează rezutatul curect pentru un caz complex; (0.5 pts)