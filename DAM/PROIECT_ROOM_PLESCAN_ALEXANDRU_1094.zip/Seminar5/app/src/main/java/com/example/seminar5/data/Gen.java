package com.example.seminar5.data;

public enum Gen {
    MASCULIN,
    FEMININ,
    INDECIS
}
